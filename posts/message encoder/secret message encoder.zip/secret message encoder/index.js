var alphabets = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5","6","7","8","9","0"];
var justlikethat = [];
change();
function change() {
    for (let tje=0; tje<37;) {
        justlikethat.push(alphabets[tje]);
        console.log(justlikethat);
        tje=tje+1;
    }

}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}
function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}
var number=[];
repeat();
function repeat() {
    for (let o=0; number.length<36;) {
        var mem=getRndInteger(100, 999);
        number.filter(onlyUnique);
        o=o+1;
        number.push(mem);
        number=number.filter(onlyUnique);
    }
}
console.log(number)
function show() {
    for (let iko=0; iko<36;) {
        if(iko<26) {
            document.getElementById("para").innerHTML=document.getElementById("para").innerHTML+"<br>"+justlikethat[iko]+"="+number[iko]+";";
            iko=iko+1;
        }
        else {
            document.getElementById("para").innerHTML=document.getElementById("para").innerHTML+"<br>"+"n"+justlikethat[iko]+"="+number[iko]+";";
            iko=iko+1;
        }
    }

}