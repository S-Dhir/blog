var output=document.getElementById("output");
function outtheput() {
    var input =document.getElementById("keywrote").value;
    let tkn=0;
    while (tkn<input.length) {
        output=document.getElementById("output");
        let currentnum=(input.charAt(tkn)+input.charAt(tkn+1)+input.charAt(tkn+2));
        if(q==currentnum) {
            output.innerHTML=output.innerHTML+"q";
        }
        if(w==currentnum) {
            output.innerHTML=output.innerHTML+"w";
        }
        if(e==currentnum) {
            output.innerHTML=output.innerHTML+"e";
        }
        if(r==currentnum) {
            output.innerHTML=output.innerHTML+"r";
        }
        if(t==currentnum) {
            output.innerHTML=output.innerHTML+"t";
        }
        if(y==currentnum) {
            output.innerHTML=output.innerHTML+"y";
        }
        if(u==currentnum) {
            output.innerHTML=output.innerHTML+"u";
        }
        if(i==currentnum) {
            output.innerHTML=output.innerHTML+"i";
        }
        if(o==currentnum) {
            output.innerHTML=output.innerHTML+"o";
        }
        if(p==currentnum) {
            output.innerHTML=output.innerHTML+"p";
        }
        if(a==currentnum) {
            output.innerHTML=output.innerHTML+"a";
        }
        if(s==currentnum) {
            output.innerHTML=output.innerHTML+"s";
        }
        if(d==currentnum) {
            output.innerHTML=output.innerHTML+"d";
        }
        if(f==currentnum) {
            output.innerHTML=output.innerHTML+"f";
        }
        if(g==currentnum) {
            output.innerHTML=output.innerHTML+"g";
        }
        if(h==currentnum) {
            output.innerHTML=output.innerHTML+"h";
        }
        if(j==currentnum) {
            output.innerHTML=output.innerHTML+"j";
        }
        if(k==currentnum) {
            output.innerHTML=output.innerHTML+"k";
        }
        if(l==currentnum) {
            output.innerHTML=output.innerHTML+"l";
        }
        if(z==currentnum) {
            output.innerHTML=output.innerHTML+"z";
        }
        if(x==currentnum) {
            output.innerHTML=output.innerHTML+"x";
        }
        if(c==currentnum) {
            output.innerHTML=output.innerHTML+"c";
        }
        if(v==currentnum) {
            output.innerHTML=output.innerHTML+"v";
        }
        if(b==currentnum) {
            output.innerHTML=output.innerHTML+"b";
        }
        if(n==currentnum) {
            output.innerHTML=output.innerHTML+"n";
        }
        if(m==currentnum) {
            output.innerHTML=output.innerHTML+"m";
        }
        if(n1==currentnum) {
            output.innerHTML=output.innerHTML+"1";
        }
        if(n2==currentnum) {
            output.innerHTML=output.innerHTML+"2";
        }
        if(n3==currentnum) {
            output.innerHTML=output.innerHTML+"3";
        }
        if(n4==currentnum) {
            output.innerHTML=output.innerHTML+"4";
        }
        if(n5==currentnum) {
            output.innerHTML=output.innerHTML+"5";
        }
        if(n6==currentnum) {
            output.innerHTML=output.innerHTML+"6";
        }
        if(n7==currentnum) {
            output.innerHTML=output.innerHTML+"7";
        }
        if(n8==currentnum) {
            output.innerHTML=output.innerHTML+"8";
        }
        if(n9==currentnum) {
            output.innerHTML=output.innerHTML+"9";
        }
        if(n0==currentnum) {
            output.innerHTML=output.innerHTML+"0";
        }
        tkn=tkn+3;
    }
}
function tonum() {
    output=document.getElementById("output");
    let currentnum;
    currentnum=currentnum;
    let tey=0;
    while (tey<document.getElementById("keywrote").value.length) {
        let input = document.getElementById("keywrote").value.charAt(tey);
        if (input=="q") {
            output.innerHTML=output.innerHTML+q;
        }
        if (input=="w") {
            output.innerHTML=output.innerHTML+w;
        }
        if (input=="e") {
            output.innerHTML=output.innerHTML+e;
        }
        if (input=="r") {
            output.innerHTML=output.innerHTML+r;
        }
        if (input=="t") {
            output.innerHTML=output.innerHTML+t;
        }
        if (input=="y") {
            output.innerHTML=output.innerHTML+y;
        }
        if (input=="u") {
            output.innerHTML=output.innerHTML+u;
        }
        if (input=="i") {
            output.innerHTML=output.innerHTML+i;
        }
        if (input=="o") {
            output.innerHTML=output.innerHTML+o;
        }
        if (input=="p") {
            output.innerHTML=output.innerHTML+p;
        }
        if (input=="a") {
            output.innerHTML=output.innerHTML+a;
        }
        if (input=="s") {
            output.innerHTML=output.innerHTML+s;
        }
        if (input=="d") {
            output.innerHTML=output.innerHTML+d;
        }
        if (input=="f") {
            output.innerHTML=output.innerHTML+f;
        }
        if (input=="g") {
            output.innerHTML=output.innerHTML+g;
        }
        if (input=="h") {
            output.innerHTML=output.innerHTML+h;
        }
        if (input=="j") {
            output.innerHTML=output.innerHTML+j;
        }
        if (input=="k") {
            output.innerHTML=output.innerHTML+k;
        }
        if (input=="l") {
            output.innerHTML=output.innerHTML+l;
        }
        if (input=="z") {
            output.innerHTML=output.innerHTML+z;
        }
        if (input=="x") {
            output.innerHTML=output.innerHTML+x;
        }
        if (input=="c") {
            output.innerHTML=output.innerHTML+c;
        }
        if (input=="v") {
            output.innerHTML=output.innerHTML+v;
        }
        if (input=="b") {
            output.innerHTML=output.innerHTML+b;
        }
        if (input=="n") {
            output.innerHTML=output.innerHTML+n;
        }
        if (input=="m") {
            output.innerHTML=output.innerHTML+m;
        }
        if (input=="1") {
            output.innerHTML=output.innerHTML+n1;
        }
        if (input=="2") {
            output.innerHTML=output.innerHTML+n2;
        }
        if (input=="3") {
            output.innerHTML=output.innerHTML+n3;
        }
        if (input=="4") {
            output.innerHTML=output.innerHTML+n4;
        }
        if (input=="5") {
            output.innerHTML=output.innerHTML+n5;
        }
        if (input=="6") {
            output.innerHTML=output.innerHTML+n6;
        }
        if (input=="7") {
            output.innerHTML=output.innerHTML+n7;
        }
        if (input=="8") {
            output.innerHTML=output.innerHTML+n8;
        }
        if (input=="9") {
            output.innerHTML=output.innerHTML+n9;
        }
        if (input=="0") {
            output.innerHTML=output.innerHTML+n0;
        }

        tey=tey+1;
    }

}